# create-flask-app

## PyPi package for creating python flask template
