def create_flask_app():
    print("creating app...")